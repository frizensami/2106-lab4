/*************************************
* Lab 4 Exercise 1
* Name:
* Student No:
* Lab Group:
*************************************
*Warning: Make sure your code works on
lab machine (Linux on x86)
*************************************/

#include <stdio.h>
#include <stdlib.h>

#define FREE 0      //To represent a free partition
#define OCCUPIED 1  //To represent an occupied partition

//Declaration of a Linked List Node
//  for handling partition information

//Note: You are free to rewrite / redesign in anyway 

typedef struct BLOCKSTRUCT{
    unsigned int address;       //starting address
    struct BLOCKSTRUCT* next;
} block;

//For easy access of power of 2s. POWEROF2[IDX] gives 2^IDX
// Upto 4096 only :-) 
int POWEROF2[] = {1, 2, 4, 8, 16, 32, 64, 
                    128, 256, 512, 1024, 2048, 4096};

//Helper Functions written for you
unsigned int pOf2Ceiling( unsigned int N );
// Find the smallest S, such that 2&S >= N
//   S is returned

unsigned int buddyOf( unsigned int , unsigned int );
//Return the address of the buddy block, at a particular power of 2

int main(int argc, char** argv)
{
    
    int initMemSize;

    scanf("%d", &initMemSize);

    //Initialize the buddy system

    //Print out the arrays

    //Clean up

    return 0;
}

unsigned int pOf2Ceiling( unsigned int N )
{
    unsigned int s = 0, pOf2 = 1;

    while( pOf2 < N){
        pOf2 <<= 1;
        s++;
    }

    return s;
}

unsigned int buddyOf( unsigned int addr, unsigned int S )
{
    unsigned int mask = 0xFFFFFFFF << S;
    unsigned int buddyBit = 0x0001 << S;

    return (addr & mask) ^ buddyBit;
}
